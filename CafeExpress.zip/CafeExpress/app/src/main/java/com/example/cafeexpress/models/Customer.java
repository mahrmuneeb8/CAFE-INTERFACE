package com.example.cafeexpress.models;

public class Customer {
    private String name;
    private String sapId;
    private String email;

    public Customer(String name, String sapId, String email) {
        this.name = name;
        this.sapId = sapId;
        this.email = email;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getSapId() { return sapId; }
    public void setSapId(String sapId) { this.sapId = sapId; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getCustomerId() {
        return "CE-" + sapId;
    }
}
