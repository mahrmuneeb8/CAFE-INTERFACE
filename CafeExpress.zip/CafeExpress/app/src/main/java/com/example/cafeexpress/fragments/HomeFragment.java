package com.example.cafeexpress.fragments;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        TextView text = new TextView(requireContext());
        text.setText("Welcome to UOL Cafe Express!\\n\\nHome");
        text.setTextSize(25);
        text.setTextColor(0xFF6D4028);
        text.setGravity(Gravity.CENTER);
        return text;
    }
}
