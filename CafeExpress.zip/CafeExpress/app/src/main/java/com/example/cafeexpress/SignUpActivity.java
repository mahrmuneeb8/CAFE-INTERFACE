package com.example.cafeexpress;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SignUpActivity extends AppCompatActivity {
    private EditText name, sap, email, password, confirm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        name = findViewById(R.id.etName);
        sap = findViewById(R.id.etSap);
        email = findViewById(R.id.etEmail);
        password = findViewById(R.id.etPassword);
        confirm = findViewById(R.id.etConfirm);
        Button signup = findViewById(R.id.btnSignUp);

        signup.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            String s = sap.getText().toString().trim();
            String e = email.getText().toString().trim();
            String p = password.getText().toString();
            String cp = confirm.getText().toString();

            if (n.isEmpty() || s.isEmpty() || e.isEmpty() || p.isEmpty() || cp.isEmpty()) {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!s.matches("\\d{8}")) {
                sap.setError("Enter exactly 8 digits");
                return;
            }
            if (!Patterns.EMAIL_ADDRESS.matcher(e).matches()) {
                email.setError("Enter a valid email");
                return;
            }
            if (!p.equals(cp)) {
                confirm.setError("Passwords do not match");
                return;
            }

            Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(SignUpActivity.this, SignInActivity.class);
            intent.putExtra("name", n);
            intent.putExtra("sapId", s);
            intent.putExtra("email", e);
            intent.putExtra("password", p);
            startActivity(intent);
            finish();
        });
    }
}
