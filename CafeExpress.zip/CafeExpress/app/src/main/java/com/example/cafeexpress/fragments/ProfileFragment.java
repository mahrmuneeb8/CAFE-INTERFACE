package com.example.cafeexpress.fragments;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        Bundle data = getArguments();
        String name = data != null ? data.getString("name", "") : "";
        String sap = data != null ? data.getString("sapId", "") : "";
        String email = data != null ? data.getString("email", "") : "";

        TextView text = new TextView(requireContext());
        text.setText("My Profile\\n\\nName: " + name
                + "\\nSAP ID: " + sap + "\\nEmail: " + email);
        text.setTextSize(20);
        text.setTextColor(0xFF6D4028);
        text.setPadding(25, 25, 25, 25);
        text.setGravity(Gravity.CENTER);
        return text;
    }
}
