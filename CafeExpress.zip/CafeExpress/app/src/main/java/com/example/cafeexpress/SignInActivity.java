package com.example.cafeexpress;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SignInActivity extends AppCompatActivity {
    private EditText email, password;
    private String savedName, savedSap, savedEmail, savedPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        email = findViewById(R.id.loginEmail);
        password = findViewById(R.id.loginPassword);
        Button login = findViewById(R.id.btnLogin);
        TextView signup = findViewById(R.id.tvNewCustomer);

        Intent data = getIntent();
        savedName = data.getStringExtra("name");
        savedSap = data.getStringExtra("sapId");
        savedEmail = data.getStringExtra("email");
        savedPassword = data.getStringExtra("password");

        if (savedEmail != null) email.setText(savedEmail);

        signup.setOnClickListener(v ->
                startActivity(new Intent(SignInActivity.this, SignUpActivity.class)));

        login.setOnClickListener(v -> {
            String enteredEmail = email.getText().toString().trim();
            String enteredPassword = password.getText().toString();

            if (savedEmail == null || savedPassword == null) {
                Toast.makeText(this, "Please sign up first", Toast.LENGTH_SHORT).show();
                return;
            }
            if (enteredEmail.equals(savedEmail) && enteredPassword.equals(savedPassword)) {
                Intent intent = new Intent(SignInActivity.this, MainActivity.class);
                intent.putExtra("name", savedName);
                intent.putExtra("sapId", savedSap);
                intent.putExtra("email", savedEmail);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
