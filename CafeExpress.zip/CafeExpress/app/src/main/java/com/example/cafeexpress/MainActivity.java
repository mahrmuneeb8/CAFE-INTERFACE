package com.example.cafeexpress;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.example.cafeexpress.fragments.HomeFragment;
import com.example.cafeexpress.fragments.MenuFragment;
import com.example.cafeexpress.fragments.ProfileFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNavigation = findViewById(R.id.bottomNavigation);

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragmentContainer, new HomeFragment())
                    .commit();
        }

        bottomNavigation.getOrCreateBadge(R.id.nav_menu).setNumber(4);

        bottomNavigation.setOnItemSelectedListener(item -> {
            Fragment fragment;
            int id = item.getItemId();

            if (id == R.id.nav_home) {
                fragment = new HomeFragment();
            } else if (id == R.id.nav_menu) {
                fragment = new MenuFragment();
            } else if (id == R.id.nav_profile) {
                ProfileFragment profile = new ProfileFragment();
                Bundle bundle = new Bundle();
                bundle.putString("name", getIntent().getStringExtra("name"));
                bundle.putString("sapId", getIntent().getStringExtra("sapId"));
                bundle.putString("email", getIntent().getStringExtra("email"));
                profile.setArguments(bundle);
                fragment = profile;
            } else {
                return false;
            }

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragmentContainer, fragment)
                    .commit();
            return true;
        });
    }
}
