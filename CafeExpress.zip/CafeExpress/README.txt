UOL CAFE EXPRESS - TASKS 1 TO 5
================================

HOW TO OPEN
1. Extract CafeExpress.zip.
2. Open Android Studio.
3. Select File > Open.
4. Select the extracted CafeExpress folder (the folder containing settings.gradle).
5. Wait for Gradle sync to finish.
6. Select an emulator or connect an Android phone, then press Run.

PROJECT SETTINGS
- Language: Java
- Package: com.example.cafeexpress
- Minimum SDK: 23
- Compile SDK: 35
- Java: 17

INCLUDED
Task 1: Splash screen and café logo
Task 2: Sign-up form with validation and wave-style header
Task 3: Sign-in and Intent data passing
Task 4: Customer and FoodItem model classes
Task 5: Bottom navigation with Home, Menu, Profile and Menu badge 4

NOTES
- This is a practical/demo implementation. User accounts are passed between activities using Intents;
  they are not saved permanently. After restarting the app, sign-up again.
- The app needs an Android SDK installed through Android Studio.
- If Android Studio asks to install SDK 35 or accept licenses, follow its prompts.
- If Gradle sync reports that plugin 8.6.1 is unavailable, allow Android Studio to update the
  Android Gradle Plugin/Gradle version using its recommended compatible version.
